#################################################################
# Prerequisites:                                                #
# Install-Module -Name ActiveDirectoryDsc -Repository PSGallery #
#################################################################

Configuration ActiveDirectoryDomainServices {

    param (

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DomainName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DomainNetBiosName,
        
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $Credential,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Management.Automation.PSCredential]
        $SafeModeAdministratorPassword

    )

    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Import-DscResource -ModuleName ActiveDirectoryDsc

    # The Node statement specifies which targets this configuration will be applied to.
    Node 'localhost' {

        # The first resource block ensures that the Web-Server (IIS) feature is enabled.
        WindowsFeature 'ADDS' {
            Ensure = 'Present'
            Name   = 'AD-Domain-Services'
        }

        WindowsFeature 'RSAT' {
            Ensure = 'Present'
            Name   = 'RSAT-AD-PowerShell'
        }

        ADDomain 'ntwrk.com' {
            DomainName                      = $DomainName
            DomainNetBiosName               = $DomainNetBiosName
            Credential                      = $Credential
            SafeModeAdministratorPassword   = $SafeModeAdministratorPassword
            ForestMode                      = 'WinTreshold'
        }

    }
}