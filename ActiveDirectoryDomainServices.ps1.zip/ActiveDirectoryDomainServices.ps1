#################################################################
# Prerequisites:                                                #
# Install-Module -Name ActiveDirectoryDsc -Repository PSGallery #
#################################################################

Configuration ActiveDirectoryDomainServices {

    param (

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $DomainName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $DomainNetBiosName,
        
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $Credential,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [PSCredential] $SafeModeAdministratorPassword

    )

    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Import-DscResource -ModuleName ActiveDirectoryDsc

    Node 'localhost' {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature 'DNS' { 
            Ensure      = "Present" 
            Name        = "DNS"		
        }

        WindowsFeature 'RSAT-DNS-Server' {
            Ensure      = "Present"
            Name        = "RSAT-DNS-Server"
            DependsOn   = "[WindowsFeature]DNS"
        }

        Script GuestAgent
        {
            SetScript  = {
                Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\WindowsAzureGuestAgent' -Name DependOnService -Type MultiString -Value DNS
                Write-Verbose -Verbose "GuestAgent depends on DNS"
            }
            GetScript   = { @{} }
            TestScript  = { $false }
            DependsOn   = "[WindowsFeature]DNS"
        }

        WindowsFeature 'ADDS' {
            Ensure      = 'Present'
            Name        = 'AD-Domain-Services'
            DependsOn   = '[WindowsFeature]DNS'
        }

        WindowsFeature 'RSAT-ADDS'
		{
			Ensure      = 'Present'
			Name        = 'RSAT-ADDS'
            DependsOn   = '[WindowsFeature]ADDS'
		}

        WindowsFeature 'RSAT-AD-PowerShell' {
            Ensure      = 'Present'
            Name        = 'RSAT-AD-PowerShell'
            DependsOn   = '[WindowsFeature]ADDS'
        }
        
        ADDomain 'ADDomain' {
            DomainName                      = $DomainName
            DomainNetBiosName               = $DomainNetBiosName
            Credential                      = $Credential
            SafeModeAdministratorPassword   = $SafeModeAdministratorPassword
            ForestMode                      = 'WinThreshold'
        }

    }
}
